<!DOCTYPE html>
<html lang="es">
<head>
	<?php include 'http://mortonsubastas.andyosuna.com/php/include-meta.php'; ?>
	
	<title>Morton Casa de Subastas - Subastas</title>

	<?php include 'http://mortonsubastas.andyosuna.com/php/include-css.php'; ?>
</head>

<body>
	<?php include 'http://mortonsubastas.andyosuna.com/php/include-header.php'; ?>

	<section id="banner">
		<img src="/images/banners/dep-arte-moderno.jpg">
	</section>

	<div id="content">

		<h1>Subastas</h1>

		<ol class="breadcrumb">
			<li><a href="/">Inicio</a></li>
			<li class="active">Subastas</li>
		</ol>

		<!-- your code here! -->

	</div><!-- end #content -->

	<?php include 'http://mortonsubastas.andyosuna.com/php/include-footer.php'; ?>

    <?php include 'http://mortonsubastas.andyosuna.com/php/include-js.php'; ?>
</body>
</html>