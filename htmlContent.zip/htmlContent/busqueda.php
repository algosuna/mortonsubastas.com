<!DOCTYPE html>
<html lang="es">
<head>
	<?php include 'http://mortonsubastas.andyosuna.com/php/include-meta.php'; ?>
	
	<title>Morton Casa de Subastas - B&uacute;squeda</title>

	<?php include 'http://mortonsubastas.andyosuna.com/php/include-css.php'; ?>
</head>

<body>
	<?php include 'http://mortonsubastas.andyosuna.com/php/include-header.php'; ?>

	<section id="banner">
		<img src="/images/banners/dep-arte-moderno.jpg">
	</section>

	<div id="content">

		<!-- your code here! -->

	</div><!-- end #content -->

	<?php include 'http://mortonsubastas.andyosuna.com/php/include-footer.php'; ?>

    <?php include 'http://mortonsubastas.andyosuna.com/php/include-js.php'; ?>
</body>
</html>