<?php

$db = mysql_connect( 'localhost','andrea_andyosuna','~aS9aR1uO!' );
mysql_select_db('andrea_mortonsubastas',$db) or die('Could not connect to DB');
